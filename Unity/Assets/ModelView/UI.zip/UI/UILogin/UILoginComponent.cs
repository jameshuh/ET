﻿using System;
using System.Net;

using UnityEngine;
using UnityEngine.UI;

namespace ET
{
	public class UILoginComponent: Entity
	{
		public GameObject account;
		public GameObject loginBtn;
	}
}
