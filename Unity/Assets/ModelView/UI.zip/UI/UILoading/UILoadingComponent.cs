﻿using UnityEngine;
using UnityEngine.UI;

namespace ET
{
	public class UILoadingComponent : Entity
	{
		public Text text;
	}
}
